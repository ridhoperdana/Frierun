package net.ridhoperdana.kelasmobileminggu10;

/**
 * Created by RIDHO on 12/5/2016.
 */

public class Config {
    public static final String FIREBASE_URL = "https://jelajah-b2228.firebaseio.com/";
}
