package net.ridhoperdana.kelasmobileminggu10;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class MapsActivity extends BaseActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private LocationListener locationListener;
    private LocationManager locationManager;
    private Location mLastLocation;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonCari = (Button) findViewById(R.id.geocoderButton);
        Button buttonGo = (Button) findViewById(R.id.buttonGo);
        Button buttonHitung = (Button) findViewById(R.id.buttonHitungJarak);
        Button buttonStartGPS = (Button)findViewById(R.id.tombol_start_peta);
        Button buttonStopGPS = (Button)findViewById(R.id.tombol_stop_peta);
        Button buttonRiwayat = (Button)findViewById(R.id.tombol_riwayat);
        database = FirebaseDatabase.getInstance();
        getLocation();
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        buttonGo.setOnClickListener(klik);
        buttonCari.setOnClickListener(klik);
        buttonHitung.setOnClickListener(klik);
        buttonStartGPS.setOnClickListener(klik);
        buttonStopGPS.setOnClickListener(klik);
        buttonRiwayat.setOnClickListener(klik);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new myListener();
    }

    private class myListener implements LocationListener {
        private EditText lat, lngt;

        @Override
        public void onLocationChanged(Location location) {
            lat = (EditText) findViewById(R.id.inputLatitude);
            lngt = (EditText) findViewById(R.id.inputLongitude);

            lat.setText(String.valueOf(location.getLatitude()));
            lngt.setText(String.valueOf(location.getLongitude()));

            goToPeta();
        }

        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) {

        }

        @Override
        public void onProviderEnabled(String s) {

        }

        @Override
        public void onProviderDisabled(String s) {

        }
    }

    private void aktifkanGPS(boolean status) {
        verifyLocationPermissions(this);
        if (status) {
            EditText waktu = (EditText) findViewById(R.id.input_waktu_refresh);
            EditText jarak = (EditText) findViewById(R.id.input_jarak_refresh);

            Integer waktunya = Integer.parseInt(waktu.getText().toString());
            Integer jaraknya = Integer.parseInt(jarak.getText().toString());

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, waktunya, jaraknya, locationListener);
            Toast.makeText(this, "GPS AKTIF WAKTU: " + waktunya + "JARAK: " + jaraknya, Toast.LENGTH_SHORT).show();
        }
        else
        {
            locationManager.removeUpdates(locationListener);
            Toast.makeText(this, "GPS TIDAK AKTIF", Toast.LENGTH_SHORT).show();
        }
    }

    private static void verifyLocationPermissions(Activity activity) {
        int permission;
        String[] PERMISSIONS_LOCATION = {
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
        };
        // Check if we have write permission
        permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_LOCATION,
                    1
            );
        }
    }

    private void goToPeta()
    {
        EditText inputLongitude = (EditText)findViewById(R.id.inputLongitude);
        EditText inputLatitude = (EditText)findViewById(R.id.inputLatitude);
        String tampungLongitude = inputLongitude.getText().toString();
        String tampungLatitude = inputLatitude.getText().toString();
        Double DoubleLongitude = Double.parseDouble(tampungLongitude);
        Double DoubleLatitude = Double.parseDouble(tampungLatitude);
        goToLokasi(DoubleLatitude, DoubleLongitude, 15);
    }

    private void goToLokasi(Double lat, Double lng, float z)
    {
        LatLng lokasBaru = new LatLng(lat, lng);
        mMap.addMarker(new MarkerOptions().position(lokasBaru).title("Marker in "+ lat +", "+ lng));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lokasBaru, z));

        DatabaseReference myRef = database.getReference().child("Riwayat");
        DatabaseReference ref = myRef.push();
        Riwayat riwayat = new Riwayat();
        riwayat.setLat(String.valueOf(lat));
        riwayat.setLongt(String.valueOf(lng));
        riwayat.setId_riwayat(1);
        ref.setValue(riwayat);
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                    Riwayat rwyt = dataSnapshot.getValue(Riwayat.class);
                    try{
                        Toast.makeText(getApplicationContext(), "Lat masuk: " + rwyt.getLat(), Toast.LENGTH_SHORT).show();
                    }catch (Exception e)
                    {
                        Toast.makeText(getApplicationContext(), "error: " + e.toString(), Toast.LENGTH_SHORT).show();
                    }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void cariLatLong(String alamat1, String alamat2) throws IOException {
        Geocoder g = new Geocoder(getBaseContext());
        Geocoder g2 = new Geocoder(getBaseContext());
        List<android.location.Address> daftar = g.getFromLocationName(alamat1, 1);
        List<android.location.Address> daftar2 = g2.getFromLocationName(alamat2, 1);
        Address alamat = daftar.get(0);
        Address alamat_2 = daftar2.get(0);
        hitungJarak(alamat.getLatitude(), alamat.getLongitude(), alamat_2.getLatitude(), alamat_2.getLongitude());
    }

    private void goCari() throws IOException {
        EditText inputGeocoder = (EditText)findViewById(R.id.inputGeocoder);
        Geocoder g = new Geocoder(getBaseContext());
        List<android.location.Address> daftar = g.getFromLocationName(inputGeocoder.getText().toString(), 1);
        Address alamat = daftar.get(0);
        String namaAlamat = alamat.getAddressLine(0);
        Double lat = alamat.getLatitude();
        Double lng = alamat.getLongitude();
        goToLokasi(lat, lng, 15);
    }

    private void aksiHitung() throws IOException {
        EditText inputAsal = (EditText)findViewById(R.id.inputAsal);
        EditText inputTujuan = (EditText)findViewById(R.id.inputTujuan);
        cariLatLong(inputAsal.getText().toString(), inputTujuan.getText().toString());
    }

    private View.OnClickListener klik = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(view.getId() == R.id.buttonGo)
            {
                sembunyikanKeyboard(view);
                goToPeta();
            }
            else if(view.getId() == R.id.geocoderButton)
            {
                try {
                    sembunyikanKeyboard(view);
                    goCari();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else if(view.getId() == R.id.buttonHitungJarak)
            {
                try {
                    sembunyikanKeyboard(view);
                    aksiHitung();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else if(view.getId() == R.id.tombol_start_peta)
            {
                aktifkanGPS(true);
            }
            else if(view.getId() == R.id.tombol_stop_peta)
            {
                aktifkanGPS(false);
            }
            else if(view.getId()==R.id.tombol_riwayat)
            {

                DatabaseReference myRef = database.getReference().child("Riwayat");
                Log.d("masuk tombol", "riwayat");
                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        int i =0;
                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                            //Getting the data from snapshot
                            Riwayat person = postSnapshot.getValue(Riwayat.class);
                            LatLng lokasBaru = new LatLng(Double.parseDouble(person.getLat()), Double.parseDouble(person.getLongt()));
                            Log.d("lat" + i + ":", person.getLat());
                            mMap.addMarker(new MarkerOptions().position(lokasBaru).title("Marker in "+ person.getLat() +", "+ person.getLongt()));
                            i++;
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        }
    };

    private void sembunyikanKeyboard(View view)
    {
        InputMethodManager a = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        a.hideSoftInputFromWindow(view.getWindowToken(), 20);
    }

    private void hitungJarak(Double latAsal, Double lngAsal, Double latTujuan, Double lngTujuan)
    {
        Location asal = new Location("asal");
        Location tujuan = new Location("tujuan");
        tujuan.setLatitude(latTujuan);
        tujuan.setLongitude(lngTujuan);
        asal.setLatitude(latAsal);
        asal.setLongitude(lngAsal);
        float jarak = (float)asal.distanceTo(tujuan)/1000;
        String hasilJarak = String.valueOf(jarak);
        Toast.makeText(getBaseContext(), "Jarak: " + hasilJarak, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.petaNormal)
            mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        else if(item.getItemId()==R.id.petaHybrid)
            mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        else if(item.getItemId()==R.id.petaTerrain)
            mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        else if(item.getItemId()==R.id.petaSatellite)
            mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
        return super.onOptionsItemSelected(item);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng its = new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude());
        //LatLngBounds sydney = new LatLngBounds(new LatLng(-34, 151))
        mMap.addMarker(new MarkerOptions().position(its).title("Marker in ITS"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(its,15));
    }

    private void getLocation()
    {
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        try{
            mLastLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (mLastLocation == null){
                mLastLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if(mLastLocation==null)
                {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, (LocationListener) this);
                    mLastLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                }
            }
            else if (mLastLocation != null)
                Log.d("Location : ","Lat = "+ mLastLocation.getLatitude() + " Lng");
        }catch (Exception e)
        {
            Log.d("Gagal lokasi terbaru", "fail");
        }
    }
}
