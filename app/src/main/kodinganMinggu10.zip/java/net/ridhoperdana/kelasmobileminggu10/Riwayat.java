package net.ridhoperdana.kelasmobileminggu10;

/**
 * Created by RIDHO on 12/5/2016.
 */

public class Riwayat {
    private String lat, longt;
    private int id_riwayat;

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLongt() {
        return longt;
    }

    public int getId_riwayat() {
        return id_riwayat;
    }

    public void setId_riwayat(int id_riwayat) {
        this.id_riwayat = id_riwayat;
    }

    public void setLongt(String longt) {
        this.longt = longt;
    }

    public Riwayat() {
    }
}
